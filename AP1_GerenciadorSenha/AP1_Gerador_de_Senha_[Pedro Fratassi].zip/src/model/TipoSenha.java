package model;

public enum TipoSenha {
    NORMAL, PREFERENCIAL
}
